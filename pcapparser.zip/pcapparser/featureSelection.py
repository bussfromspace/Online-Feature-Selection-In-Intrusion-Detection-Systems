import os, sys
import numpy as np
import pandas as pd
# ...
import pdb

from scapy.all import *
from io import StringIO
from utils import convertIPs
from scipy.stats import pearsonr
from sklearn.tree import DecisionTreeClassifier
from sklearn.feature_selection import f_regression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold
from sklearn.ensemble import BaggingClassifier, RandomForestClassifier
from sklearn.metrics import confusion_matrix, classification_report, mean_squared_error, accuracy_score
#
from sklearn.multiclass import OneVsRestClassifier
from sklearn.svm import SVC


def Sanitize(df):
	#extract zero variance or NaN features from data
	fields = df.columns
	#replace min value of the data frame to NaN to have correct mean and variance calculations
	nanval = min(df.min(numeric_only=True))
	df = df.replace(nanval, np.nan)
	var = df.var(skipna=True)

	#drop columns with full NaN values
	df = df.dropna(how='all')
	header = df.columns
	diff = tuple(set(fields)-set(header))
	print ('columns with full NaN values removed from learning set:\n')
	print (diff)

	#drop columns with zero variance, i.e. constant in field 
	df = df.drop(df.columns[df.apply(lambda col: col.var(skipna=True) == 0)], axis=1)
	header = df.columns
	diff = tuple(set(fields)-set(header))
	print ('columns with zero variances are removed from learning set:\n')
	print (diff)

	SanitizedDF = df.replace(np.nan, -1.0)
	return SanitizedDF

def Normalize(df):
	#convert IPs to 4 different features
	df = convertIPs(df)
	#Normalize data between 0-1
	df = Sanitize(df)
	#replace min value of the data frame to NaN to have correct mean and variance calculations
	nanval = min(df.min(numeric_only=True))
	df = df.replace(nanval, np.nan)
	df_norm = abs(df - df.mean(skipna=True))/ df.var(skipna=True)
	df_norm = df_norm.replace(np.nan, -1.0)
	return df_norm

def main(argv):
	X = pd.read_csv(argv[1])
	Y = pd.read_csv(argv[2], header=None)
	X = X.drop(X.columns[[0]], axis=1)  #1st attack 153405
	Y = Y.drop(Y.columns[[0]], axis=1)
	#normalize data
	Xattack = X.loc[np.where(Y == 1)[0]]
	Xnormal = X.loc[np.where(Y == -1)[0]]
	Xunknown = X.loc[np.where(Y == 0)[0]]

	Xnormal  = Xnormal.sample(n=len(Xattack))
	Xunknown = Xunknown.sample(n=len(Xattack))
	Ynormal  = Y.loc[Xnormal.index]
	Yattack  = Y.loc[Xattack.index]
	Yunknown = Y.loc[Xunknown.index] 

	Y = pd.concat([Ynormal, Yattack, Yunknown])
	X = pd.concat([Xnormal, Xattack, Xunknown])
	Y.index = range(len(Y))
	X.index = range(len(X))

	X = Normalize(X)
	y = Y.iloc[:,0]

	# stratification n_splits default=3
	skf = StratifiedKFold(n_splits=2, shuffle=True)
	maxFeaturesRange = range(2, 22, 2)

	clf = DecisionTreeClassifier() #SVC(kernel='linear') #
	n_estimators = 10
	clf = OneVsRestClassifier(BaggingClassifier(SVC(kernel='linear', probability=True, class_weight='balanced'), max_samples=1.0 / 	n_estimators, n_estimators=n_estimators))

	accuracyF  = np.empty(shape=[0,0])
	accuracyRF = np.empty(shape=[0,0]) 

	for maxnum in maxFeaturesRange:
		print('\ntraining with ', maxnum, ' features')
		#create empty Y_observed and Y_predicted data vector
		i = 1
		kfold = skf.split(X,y)
		Y_val  = np.empty(shape=[0, 0])
		Y_pred = np.empty(shape=[0, 0])
		
		for train_index, val_index in kfold:
			#separate the data into training and validation sets
			Xtrain, Xval = X.iloc[train_index,:], X.iloc[val_index,:]
			ytrain, yval = Y.iloc[train_index,0], Y.iloc[val_index,0]

			#compute f score and sort by rank
			F, pval  = f_regression(Xtrain, ytrain, center=True)
			ranks = pd.DataFrame(F, index=X.columns, columns = ['F-test'])
			ranks = ranks.sort_values(by='F-test',ascending = False)

			#select features with maxnum of features
			#selectedFeatures = ranks.index
			selectedFeatures = ranks[:maxnum].index
			#print ('f score')
			#print('selected features: ', selectedFeatures)

			#Train the model using selected features
			clf.fit(Xtrain[selectedFeatures], ytrain)

			# predict the validation set with model
			ypred = clf.predict(Xval[selectedFeatures]) 
			Y_val  = np.append(Y_val,  yval)
			Y_pred = np.append(Y_pred, ypred)
			#print (clf.feature_importances_) 
			print (i)
			i += 1 

		#compute confusion matrix and MSE
		cm = confusion_matrix(Y_val, Y_pred)
		print ('\nMean Squared Error:', mean_squared_error(Y_val, Y_pred))
		print ('\nClassification report:\n', classification_report(Y_val, Y_pred))
		print ('\nConfusion matrix:\n',  cm)
		accuracyF = np.append(accuracyF, accuracy_score(Y_val, Y_pred))

		#Add rf to feature selection
		rf = RandomForestClassifier()
		clf = SVC(kernel='linear') #DecisionTreeClassifier()

		#create empty Y_observed and Y_predicted data vector
		i = 1
		kfold = skf.split(X,y)
		Y_val  = np.empty(shape=[0, 0])
		Y_pred = np.empty(shape=[0, 0])
		
		for train_index, val_index in kfold:
			#separate the data into training and validation sets
			Xtrain, Xval = X.iloc[train_index,:], X.iloc[val_index,:]
			ytrain, yval = Y.iloc[train_index,0], Y.iloc[val_index,0]

			#compute f score and sort by rank
			F, pval  = f_regression(Xtrain, ytrain, center=True)
			ranks = pd.DataFrame(F, index=X.columns, columns = ['F-test'])
			ranks = ranks.sort_values(by='F-test',ascending = False)

			#compute rf importances
			selectedFeatures = ranks[:25].index
			rf.fit(Xtrain[selectedFeatures], ytrain)
			ranks2 = pd.DataFrame(rf.feature_importances_,index=selectedFeatures, columns = ['RF'])
			ranks2 = ranks2.sort_values(by='RF',ascending = False)
			selectedFeatures2 = ranks2[:maxnum].index

			print ('f score + RF importance')
			print('selected features: ', selectedFeatures2)

			#Train the model using selected features
			clf.fit(Xtrain[selectedFeatures2], ytrain)

			# predict the validation set with model
			ypred = clf.predict(Xval[selectedFeatures2]) 
			Y_val  = np.append(Y_val, yval)
			Y_pred = np.append(Y_pred,ypred)

			print (i)
			i += 1 

		cm = confusion_matrix(Y_val, Y_pred)
		print ('\nMean Squared Error:', mean_squared_error(Y_val, Y_pred))
		print ('\nClassification report:\n', classification_report(Y_val, Y_pred))
		print ('\nConfusion matrix:\n',  cm)
		accuracyRF = np.append(accuracyRF, accuracy_score(Y_val, Y_pred))

	plt.figure(figsize=(8, 6))
	plt.plot(maxFeaturesRange, accuracyF, 'g-', label='f-score')
	plt.plot(maxFeaturesRange, accuracyRF, 'b-', label='RF importance')
	plt.legend(loc='upper right', fancybox=True, fontsize=8)
	plt.ylabel('accuracy')
	plt.tight_layout()
	plt.grid(True)
	plt.show()
	plt.close()

if  __name__ == '__main__':
    main(sys.argv)
