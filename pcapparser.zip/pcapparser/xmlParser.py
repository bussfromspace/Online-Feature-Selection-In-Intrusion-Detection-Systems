import os, sys
import numpy as np
import pandas as pd
import datetime,time
from lxml import etree
from io import StringIO
import xml.etree.ElementTree as ET

import pdb

#xml file informations are initialized as empty lists
pattern = '%Y-%m-%dT%H:%M:%S' #date pattern in xml file
source, protocolName, sourcePort, destination, destinationPort, startDateTime, stopDateTime,Tag = [],[],[],[],[],[],[],[]
appName, direction, totalSourceBytes, totalDestinationBytes, totalSourcePackets, totalDestinationPackets, sourcePayloadAsBase64, sourcePayloadAsUTF, destinationPayloadAsBase64, 		    	    destinationPayloadAsUTF = [],[],[],[],[],[],[],[],[],[]
direction, sourceTCPFlagsDescription, destinationTCPFlagsDescription = [],[],[]
header = ['appName', 'direction', 'totalSourceBytes','totalDestinationBytes','totalSourcePackets','totalDestinationPackets', 
	       'source', 'protocolName', 'sourcePort', 'destination','destinationPort', 'startDateTime', 'stopDateTime','Tag','matched']
#sequential processing of elements in xml file
def processParameters(elem):
	#fill the lists
	if elem.tag == 'appName':
		appName.append(elem.text)
	elif elem.tag == 'direction':
		direction.append(elem.text)
	elif elem.tag == 'totalSourceBytes':
		totalSourceBytes.append(int(elem.text))
	elif elem.tag == 'totalDestinationBytes':
		totalDestinationBytes.append(int(elem.text))
	elif elem.tag == 'totalSourcePackets':
		totalSourcePackets.append(int(elem.text))
	elif elem.tag == 'totalDestinationPackets':
		totalDestinationPackets.append(int(elem.text))
	elif elem.tag == 'source':
		source.append(elem.text)
	elif elem.tag == 'protocolName':
		protocolName.append(elem.text)
	elif elem.tag == 'sourcePort':
		sourcePort.append(int(elem.text))
	elif elem.tag == 'destination':
		destination.append(elem.text)
	elif elem.tag == 'destinationPort':
		destinationPort.append(int(elem.text))
	elif elem.tag == 'startDateTime':
		startDateTime.append(int(time.mktime(time.strptime(elem.text, pattern))));
	elif elem.tag == 'stopDateTime':
		stopDateTime.append(int(time.mktime(time.strptime(elem.text, pattern))));
	elif elem.tag == 'Tag':
		Tag.append(elem.text)

def extractXmlTable(argv,l):
	for arg in (argv[2:2+l]):
		xmlContext = etree.iterparse(arg)
		for event, elem in xmlContext:
			processParameters(elem)
			elem.clear()
			while elem.getprevious() is not None:
				del elem.getparent()[0]
	# create 2d list and return this 
	totalxmllength = len(appName)
	matched = pd.Series(np.zeros(totalxmllength, dtype=np.int))
	listxml = np.array([appName, direction, totalSourceBytes,totalDestinationBytes,totalSourcePackets,totalDestinationPackets, 
	       		    source, protocolName, sourcePort, destination,destinationPort, startDateTime, stopDateTime,Tag,matched])
	
	#save xml as pandas table for comparison
	df = pd.DataFrame(listxml,header)
	df = df.transpose()
	df = df.drop_duplicates()
	uniquexmllength  = df.shape[0]
	df.to_csv('xmlStats.csv')
	print ('xml file(s) have been read.')
	return df, totalxmllength, uniquexmllength

def PacketProfileMatching(packetStats, xmlStats):
	#get profile properties 	
	startxml   = xmlStats.startDateTime.astype(int)
	stopxml    = xmlStats.stopDateTime.astype(int)
	srcPortxml = xmlStats.sourcePort.astype(int)
	dstPortxml = xmlStats.destinationPort.astype(int)
	srcIPxml   = xmlStats.source
	dstIPxml   = xmlStats.destination
	tagxml     = xmlStats.Tag

	#create Y label matrix
	sLength = len(packetStats)
	labels = pd.Series(np.zeros(sLength, dtype=np.int))
	countTagNormal  = 0
	countTagAttack  = 0
	countTagUnknown = 0
	countTagXml     = 0
	tagAttack  =  1
	tagNormal  = -1
	tagUnknown =  0
	epochOffset1 = 25200   #pcap file is 7 hours, 2-4 minutes (25200 epochs)  ahead 
	epochOffset2 = 59200
	count = 0

	for i in range(len(packetStats)):	
		packetArrival = int(packetStats['frame.time_epoch'][i])
		#mask_epoch1   = (packetArrival - startxml >= epochOffset1)
		#mask_epoch2   = (packetArrival - startxml <= epochOffset2)
		masksrcPort   = (srcPortxml == packetStats['tcp.srcport'][i])
		maskdstPort   = (dstPortxml == packetStats['tcp.dstport'][i])
		masksrcIP = (srcIPxml == packetStats['ip.src'][i])
		maskdstIP = (dstIPxml == packetStats['ip.dst'][i])
		mask = (masksrcIP == 1) & (maskdstIP == 1) & (masksrcPort == 1) & (maskdstPort == 1)
		if any(mask):
			if  tagxml[mask].iloc[0] =='Normal':
				xmlStats.loc[mask,'matched'] = 1
				labels.iloc[i] = tagNormal
				countTagNormal = countTagNormal+1
			elif tagxml[mask].iloc[0] == 'Attack':
				xmlStats.loc[mask,'matched'] = 1
				labels.iloc[i] = tagAttack
				countTagAttack = countTagAttack+1
			#print row
		else:
			countTagUnknown = countTagUnknown+1
		count = count+1
		b = "Comparison" + "%" + str(int(count*100/sLength))
		sys.stdout.write('\r' + b)
	matchedxmllength = sum(xmlStats.matched.astype(int))
	return labels,countTagNormal,countTagAttack,countTagUnknown,matchedxmllength









