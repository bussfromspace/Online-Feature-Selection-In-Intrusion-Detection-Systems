import os, sys
import numpy as np
import pandas as pd
from scapy.all import *
from io import StringIO
#from subprocess import Popen
# ...
import pdb
#external *.py files
from xmlParser import extractXmlTable, PacketProfileMatching
from utils import convertHexString, convertMACString, convertHTTPMethods
#...
#"-Y", "ip": ip filter for tshark command
#"-e", "ipv6.src", "-e", "ipv6.dst", "-e", "ipv6.plen", "-e", "ipv6.nxt", "-e", "ipv6.hlim",  #possible ipv6 header properties
#icmpv6 can be added for further features
commandArgs = ['tshark', '-r', 'pcap file',
		 '-T', 'fields', 
		 '-Y', 'ip',
		 '-e', 'eth.src',    '-e', 'eth.dst', '-e', 'eth.type', '-e', 'frame.len', #Ethernet II framing properties
		 '-e', 'frame.time_epoch', '-e', 'frame.time_delta',                       # connection starting time, duration of connection
		 '-e', 'ip.version',       '-e', 'ip.hdr_len', '-e', 'ip.dsfield.dscp', '-e', 'ip.len',  #ip packet header 0-32 bits
		 '-e', 'ip.id',  '-e', 'ip.flags', '-e', 'ip.frag_offset',  #ip packet header 32-64  bits
		 '-e', 'ip.ttl', '-e', 'ip.proto', '-e', 'ip.checksum',     #ip packet header 64-96  bits 
		 '-e', 'ip.src',      '-e', 'ip.dst',                       #ip packet header 96-160 bits
		 '-e', 'tcp.srcport', '-e', 'tcp.dstport',                  #tcp port numbers
		 '-e', 'udp.srcport', '-e', 'udp.dstport',                  #udp port numbers
		 '-e', 'icmp.type',   '-e', 'icmp.code',                    #possible icmp header properties
										    #fragmentation occurs if icmp.type==3 and icmp.code==4
		 '-e', 'ip.flags.mf', '-e', 'ip.frag_offset',               #fragmentation occurs if ip.flags.mf == 1 or ip.frag_offset > 0
		 '-e', 'ip.fragment.overlap', 				    #overlapping fragments 0/1
		 '-e', 'tcp.flags.ack',					    #tcp ack packets 0/1
		 '-e', 'tcp.analysis.retransmission',			    #retransmitted packets
		 '-e', 'tcp.flags.push',					    #pushed packets 0/1
		 '-e', 'tcp.flags.syn', '-e', 'tcp.flags.fin',              #syn and fin packets 0/1
		 '-e', 'tcp.flags.urg',					    #urgent packets 0/1
		 #'-e', 'http.request','-e', 'http.request.method',   #HTTP request and 0/1, #HTTP request method ##NOT in 14-12
		 #'-e', 'ip.fragment', '-e', 'ip.fragment.error', '-e', 'ip.fragment.count', '-e', 'ip.fragment.overlap.conflict',#NOT in 14-12
		 '-E', 'header=y', '-E', 'separator=,', '-E', 
		 'quote=d', '-E', 'occurrence=f']

def main(argv):
	print ('Number of arguments:', len(sys.argv), 'arguments.')
	print ('Argument List:', str(sys.argv)) 

	l = int(argv[1])
	
	#extract the amount of xml file to be concetaneted 
	#extract the xml content as text file
	xmlStats, totalxmllength, uniquexmllength = extractXmlTable(argv,l)

	commandArgs[2] = argv[2+l] #"Win32.DDOS.Dishigy.B-1.pcap"#testbed-12jun.pcap""
	with open("packetStatistics.txt", "w") as f:
		p = subprocess.Popen(commandArgs, stdout=f)
	#Wait subprocess to finish
	p_status = p.wait()
	print('packet-level statistics have been extracted')	
	packetStats = pd.read_csv("packetStatistics.txt")
	packetStats = convertHexString(packetStats)
	print('hex strings are converted')
	packetStats = convertMACString(packetStats)
	print('mac strings are converted')
	#packetStats = convertHTTPMethods(packetStats)
	os.remove("packetStatistics.txt")

	print('extracting labels for pcaps')
	labels,countTagNormal,countTagAttack,countTagUnknown,matchedxmllength = PacketProfileMatching(packetStats, xmlStats)
	
	Xstr = "packetStatistics" + argv[2+l][-6:-5] + ".txt"
	Ystr = "labels" + argv[2+l][-6:-5] + ".txt"
	packetStats.to_csv(Xstr)
	labels.to_csv(Ystr)

	print ('\nNormal labeled tag count in extracted Packets: ',countTagNormal)
	print ('Attack labeled tag count in extracted Packets: ',countTagAttack)
	print ('Unknown labels in extracted Packets: ',countTagUnknown)
	print ('From',uniquexmllength, ' unique entries in xml file',matchedxmllength,' of them is matched')
	print ('Total lines in xml with repetitive entries: ', totalxmllength)

if  __name__ == '__main__':
    main(sys.argv)
