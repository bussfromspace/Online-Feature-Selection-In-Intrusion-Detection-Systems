import pdb
import time
import os, sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from io import StringIO
from sklearn.svm import SVC
from sklearn.decomposition import PCA
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import confusion_matrix
from sklearn.tree import DecisionTreeClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.gaussian_process.kernels import RBF
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.gaussian_process import GaussianProcessClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis

from utils import convertIPs

#['blue', 'green', 'red', 'cyan', 'magenta', 'yellow', 'black', 'purple', 'pink', 'brown', 'orange', 'teal', 'coral', 'lightblue', 'lime', 'lavender', 'turquoise', 'darkgreen', 'tan', 'salmon', 'gold', 'lightpurple', 'darkred', 'darkblue']
#names = ["Nearest Neighbors", "Linear SVM", "RBF SVM", "Gaussian Process",
#         "Decision Tree", "Random Forest", "Neural Net", "AdaBoost",
#         "Naive Bayes", "QDA"]

names = ["N Neighbors", "Log Regression", "Decision Tree", "Random Forest", "Neural Net", "AdaBoost", "Naive Bayes", "QDA"]
colors = ["blue", "green", "red", "cyan", "magenta", "yellow", "purple", "orange"]
classifiers = [
	KNeighborsClassifier(3),
	#SVC(kernel="linear", C=0.025),
	#SVC(gamma=2, C=1),
	LogisticRegression(solver='lbfgs', C=1e5),
	DecisionTreeClassifier(max_depth=5),
	RandomForestClassifier(max_depth=5, n_estimators=10, max_features=1),
	MLPClassifier(activation='logistic',alpha=1),
	AdaBoostClassifier(),
	GaussianNB(),
	QuadraticDiscriminantAnalysis()]

def Sanitize(df):
	#extract zero variance or NaN features from data
	fields = df.columns
	#replace min value of the data frame to NaN to have correct mean and variance calculations
	nanval = min(df.min(numeric_only=True))
	df = df.replace(nanval, np.nan)
	var = df.var(skipna=True)

	#drop columns with full NaN values
	df = df.dropna(how='all')
	header = df.columns

	#drop columns with zero variance, i.e. constant in field 
	df = df.drop(df.columns[df.apply(lambda col: col.var(skipna=True) == 0)], axis=1)
	header = df.columns

	SanitizedDF = df.replace(np.nan, -1.0)
	return SanitizedDF

def Normalize(df):
	#convert IPs to 4 different features
	df = convertIPs(df)
	#Normalize data between 0-1
	df = Sanitize(df)
	#replace min value of the data frame to NaN to have correct mean and variance calculations
	nanval = min(df.min(numeric_only=True))
	df = df.replace(nanval, np.nan)
	dfnormalized = abs(df - df.mean(skipna=True))/ df.var(skipna=True)
	dfnormalized = dfnormalized.replace(np.nan, -1.0)
	return dfnormalized

def main(argv):
	#read data and labels 
	X = pd.read_csv(argv[1])
	Y = pd.read_csv(argv[2], header=None)
	X = X.drop(X.columns[[0]], axis=1)
	Y = Y.drop(Y.columns[[0]], axis=1)

	#remove nan features from input data and normalize input data
	X = Normalize(X)
	#apply PCA to input data
	pca = PCA(n_components = 20)
	X = pca.fit_transform(X)
	#split dataset into training and test part
	X_train, X_test, y_train, y_test = train_test_split(X, np.asarray(Y), stratify= np.asarray(Y), test_size=.4, random_state=42)

	#define metrics
	accuracyScore = np.empty(shape=[0])
	timeComplexityTest = np.empty(shape=[0])
	timeComplexityTrain = np.empty(shape=[0])

	#iterate over classifiers
	for name, clf in zip(names, classifiers):
		print (name)
		#fit the model using training data
		startTraining = time.time()
		clf.fit(X_train, y_train.ravel())
		finishTraining = time.time()
		y_pred = clf.predict(X_test)
		finishPredicting = time.time()
		#return the mean accuracy on the given test data 
		accuracyScore = np.append(accuracyScore, clf.score(X_test, y_test.ravel()))
		timeComplexityTrain = np.append(timeComplexityTrain, (finishTraining-startTraining))
		timeComplexityTest  = np.append(timeComplexityTest,  (finishPredicting - finishTraining))
		print ("\nConfusion matrix:\n",  confusion_matrix(y_test, y_pred))

	plt.figure(figsize=(21,24))
	plt.subplot(3,1,1)
	plt.bar(range(len(classifiers)), timeComplexityTrain, align='center', color = colors)
	plt.ylabel("Elapsed training time (seconds)")
	plt.subplot(3,1,2)
	plt.bar(range(len(classifiers)), timeComplexityTest, align='center', color = colors)
	plt.ylabel("Elapsed test time (seconds)")
	plt.subplot(3,1,3)
	plt.bar(range(len(classifiers)), accuracyScore, align='center', color = colors)
	plt.xticks(range(len(classifiers)), names, rotation=10)
	plt.ylabel("Accuracy")
	plt.savefig('CompareModels.eps', format='eps', dpi=600)
	plt.show()
	plt.close()

if  __name__ == '__main__':
    main(sys.argv)
